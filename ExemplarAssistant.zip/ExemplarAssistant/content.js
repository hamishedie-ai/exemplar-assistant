// Runs on the profiling site. Does exactly what a person would do by hand:
// opens the pickers, ticks boxes, types in fields. It never clicks "Save & Submit".
// Every action is requested by the side panel, after the apprentice has reviewed the plan.

(() => {
  if (window.__pcaLoaded) return;
  window.__pcaLoaded = true;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) =>
    (s || "")
      .toLowerCase()
      .replace(/[\u2010-\u2015]/g, "-")
      .replace(/\s+/g, " ")
      .trim();

  async function waitFor(fn, ms = 6000) {
    const start = Date.now();
    while (Date.now() - start < ms) {
      const v = fn();
      if (v) return v;
      await sleep(100);
    }
    return null;
  }

  const isVisible = (el) => !!(el && (el.offsetParent || el.getClientRects().length));

  function setValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  function findClickable(text) {
    const want = norm(text);
    return [...document.querySelectorAll("button, a")].find(
      (e) => isVisible(e) && norm(e.textContent) === want
    );
  }

  const dialog = () => document.querySelector("mat-dialog-container");

  async function openDialogFrom(buttonText) {
    const btn = findClickable(buttonText);
    if (!btn) throw new Error(`Couldn't find the "${buttonText}" button on the page.`);
    btn.click();
    const d = await waitFor(dialog);
    if (!d) throw new Error(`The "${buttonText}" picker didn't open.`);
    await sleep(300);
    return d;
  }

  async function closeDialog(buttonText) {
    const d = dialog();
    if (!d) return;
    const b = [...d.querySelectorAll("button")].find((x) => norm(x.textContent) === norm(buttonText));
    if (b) b.click();
    await waitFor(() => !dialog(), 4000);
    await sleep(300);
  }

  // Pick an option in an Angular Material <mat-select>.
  async function chooseInSelect(selectEl, optionText, { contains = false } = {}) {
    selectEl.click();
    const opts = await waitFor(() => {
      const list = [...document.querySelectorAll("mat-option")];
      return list.length ? list : null;
    });
    if (!opts) throw new Error("The dropdown didn't open.");
    const want = norm(optionText);
    const hit = opts.find((o) => (contains ? norm(o.textContent).includes(want) : norm(o.textContent) === want));
    if (!hit) {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      const names = opts.map((o) => o.textContent.trim()).join(", ");
      throw new Error(`Option "${optionText}" not found. Available: ${names}`);
    }
    hit.click();
    await sleep(400);
  }

  function checkboxLabel(cb) {
    return norm(cb.innerText || cb.textContent);
  }

  async function tickBoxes(wanted) {
    const d = dialog();
    const boxes = [...d.querySelectorAll("mat-checkbox")];
    const missing = [];
    for (const w of wanted) {
      const hit = boxes.find((b) => checkboxLabel(b) === norm(w));
      if (!hit) {
        missing.push(w);
        continue;
      }
      const input = hit.querySelector('input[type="checkbox"]');
      if (input && !input.checked) {
        input.click();
        await sleep(60);
      }
    }
    return missing;
  }

  const handlers = {
    async ping() {
      return { path: location.pathname, onForm: /\/cards\/(add|edit)/.test(location.pathname) };
    },

    async setHeader({ start, end, supervisor }) {
      const s = document.querySelector('[formcontrolname="start_time"]');
      const e = document.querySelector('[formcontrolname="end_time"]');
      if (!s || !e) throw new Error("This doesn't look like the card form. Open Cards > New Card first.");
      setValue(s, start);
      await sleep(200);
      setValue(e, end);
      await sleep(200);
      let supervisorNote = "";
      if (supervisor) {
        const sel = document.querySelector('[formcontrolname="nominated_supervisor"]');
        try {
          await chooseInSelect(sel, supervisor, { contains: true });
        } catch (err) {
          supervisorNote = `Supervisor not set (${err.message}). Please pick it yourself.`;
        }
      }
      return { startNow: s.value, endNow: e.value, supervisorNote };
    },

    // Step 1 of an entry: choose the work area, then report which equipment ranges the site offers for it.
    async beginEntry({ workArea }) {
      const d = await openDialogFrom("Work area");
      const radios = [...d.querySelectorAll("mat-radio-button")];
      const hit = radios.find((r) => norm(r.innerText || r.textContent) === norm(workArea));
      if (!hit) {
        await closeDialog("Cancel");
        throw new Error(`Work area "${workArea}" isn't in the site's list.`);
      }
      const input = hit.querySelector('input[type="radio"]');
      (input || hit).click();
      await sleep(300);
      await closeDialog("Save");

      // Read the equipment ranges the site offers for this work area (then cancel; nothing is changed).
      const ed = await openDialogFrom("Equipment Ranges");
      const options = [...ed.querySelectorAll("mat-checkbox")].map((c) => (c.innerText || c.textContent).trim().replace(/\s+/g, " "));
      await closeDialog("Cancel");
      return { equipmentOptions: options };
    },

    // Step 2 of an entry: everything else, then press Add.
    async fillEntry({ hours, support, activities, equipment, note, photos }) {
      const report = { missingActivities: [], missingEquipment: [], notes: [] };

      const h = document.querySelector('[formcontrolname="minutes_worked"]');
      if (!h) throw new Error("Couldn't find the Hours worked box.");
      setValue(h, String(hours));
      await sleep(300);

      if (support) {
        const sel = document.querySelector('[formcontrolname="supervision_level"]');
        await chooseInSelect(sel, support);
      }

      if (activities && activities.length) {
        await openDialogFrom("Activities");
        report.missingActivities = await tickBoxes(activities);
        await closeDialog("Save");
      }

      if (equipment && equipment.length) {
        await openDialogFrom("Equipment Ranges");
        report.missingEquipment = await tickBoxes(equipment);
        await closeDialog("Save");
      }

      const n = document.querySelector('[formcontrolname="workareaNote"]');
      if (n && note) {
        setValue(n, note.slice(0, 10000));
        await sleep(200);
      }

      if (photos && photos.length) {
        const fileInput = document.querySelector('input[type="file"]');
        if (fileInput) {
          const dt = new DataTransfer();
          for (const p of photos) {
            const blob = await (await fetch(p.dataUrl)).blob();
            dt.items.add(new File([blob], p.name, { type: blob.type || "image/jpeg" }));
          }
          fileInput.files = dt.files;
          fileInput.dispatchEvent(new Event("change", { bubbles: true }));
          await sleep(800);
        } else {
          report.notes.push("Couldn't find the photo upload box, so photos weren't attached.");
        }
      }

      const add = findClickable("Add");
      if (!add) throw new Error("Couldn't find the Add button.");
      add.click();
      await sleep(1200);

      const totalEl = [...document.querySelectorAll("*")].find(
        (e) => e.children.length < 3 && /total card hours/i.test(e.textContent || "")
      );
      report.totalHoursText = totalEl ? totalEl.textContent.trim().replace(/\s+/g, " ").slice(0, 80) : "";
      return report;
    },

    // Only ever "Save as Draft". Submitting is always left to the person.
    async saveDraft() {
      const btn = findClickable("Save as Draft");
      if (!btn) throw new Error("Couldn't find the Save as Draft button.");
      if (/submit/i.test(btn.textContent)) throw new Error("Refusing to click a submit button.");
      btn.click();
      await sleep(1500);
      return { clicked: true };
    },
  };

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.target !== "pca") return;
    const fn = handlers[msg.cmd];
    if (!fn) {
      sendResponse({ ok: false, error: "Unknown command" });
      return;
    }
    fn(msg.args || {})
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message || String(err) }));
    return true;
  });
})();
